#include "fix_contact_atom_counter_wall_dummy.h"
