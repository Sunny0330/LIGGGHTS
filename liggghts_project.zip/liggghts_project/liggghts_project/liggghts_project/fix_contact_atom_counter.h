#include "fix_contact_atom_counter_dummy.h"
