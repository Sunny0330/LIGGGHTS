﻿/* ----------------------------------------------------------------------
This is the

██╗     ██╗ ██████╗  ██████╗  ██████╗ ██╗  ██╗████████╗███████╗
██║     ██║██╔════╝ ██╔════╝ ██╔════╝ ██║  ██║╚══██╔══╝██╔════╝
██║     ██║██║  ███╗██║  ███╗██║  ███╗███████║   ██║   ███████╗
██║     ██║██║   ██║██║   ██║██║   ██║██╔══██║   ██║   ╚════██║
███████╗██║╚██████╔╝╚██████╔╝╚██████╔╝██║  ██║   ██║   ███████║
╚══════╝╚═╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝®

DEM simulation engine, released by
DCS Computing Gmbh, Linz, Austria
http://www.dcs-computing.com, office@dcs-computing.com

LIGGGHTS® is part of CFDEM®project:
http://www.liggghts.com | http://www.cfdem.com

Core developer and main author:
Christoph Kloss, christoph.kloss@dcs-computing.com

LIGGGHTS® is open-source, distributed under the terms of the GNU Public
License, version 2 or later. It is distributed in the hope that it will
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. You should have
received a copy of the GNU General Public License along with LIGGGHTS®.
If not, see http://www.gnu.org/licenses . See also top-level README
and LICENSE files.

LIGGGHTS® and CFDEM® are registered trade marks of DCS Computing GmbH,
the producer of the LIGGGHTS® software and the CFDEM®coupling software
See http://www.cfdem.com/terms-trademark-policy for details.

-------------------------------------------------------------------------
Contributing author and copyright for this file:

Christoph Kloss (DCS Computing GmbH, Linz)
Christoph Kloss (JKU Linz)
Stefan Amberger (JKU Linz)

Copyright 2012-     DCS Computing GmbH, Linz
Copyright 2009-2012 JKU Linz
------------------------------------------------------------------------- */

#ifndef DOMAIN_WEDGE_H
#define DOMAIN_WEDGE_H

#include "domain.h"

namespace LAMMPS_NS {

	class DomainWedge : public Domain
	{

	public:

		DomainWedge(class LAMMPS *lmp) : Domain(lmp) {};
		void set_domain(class RegWedge *rw) {}

		inline int index_axis()
		{
			return 0;
		}

		inline int index_phi()
		{
			return 0;
		}

		inline void n1(double *_n1)
		{ }

		inline void n2(double *_n2)
		{ }

		inline void center(double *_c)
		{ }
	};

}

#endif
