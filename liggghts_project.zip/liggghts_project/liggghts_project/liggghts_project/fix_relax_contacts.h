#include "fix.h" 
namespace LAMMPS_NS { class FixRelaxContacts : public Fix { public: inline double factor_relax(int) { return 1.; } }; }
