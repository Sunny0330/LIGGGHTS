#include "fix.h" 
namespace LAMMPS_NS { class FixCalculateWallEnergy : public Fix { public: void dissipate_energy(const double, const bool) {} }; }
