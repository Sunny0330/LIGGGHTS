#include "fix.h" 
namespace LAMMPS_NS { class FixInsertStreamPredefined : public FixInsertStream { public: void copy_history(const int, const int, double * const) const {} }; }
