﻿/* ----------------------------------------------------------------------
This is the

██╗     ██╗ ██████╗  ██████╗  ██████╗ ██╗  ██╗████████╗███████╗
██║     ██║██╔════╝ ██╔════╝ ██╔════╝ ██║  ██║╚══██╔══╝██╔════╝
██║     ██║██║  ███╗██║  ███╗██║  ███╗███████║   ██║   ███████╗
██║     ██║██║   ██║██║   ██║██║   ██║██╔══██║   ██║   ╚════██║
███████╗██║╚██████╔╝╚██████╔╝╚██████╔╝██║  ██║   ██║   ███████║
╚══════╝╚═╝ ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚══════╝®

DEM simulation engine, released by
DCS Computing Gmbh, Linz, Austria
http://www.dcs-computing.com, office@dcs-computing.com

LIGGGHTS® is part of CFDEM®project:
http://www.liggghts.com | http://www.cfdem.com

Core developer and main author:
Christoph Kloss, christoph.kloss@dcs-computing.com

LIGGGHTS® is open-source, distributed under the terms of the GNU Public
License, version 2 or later. It is distributed in the hope that it will
be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. You should have
received a copy of the GNU General Public License along with LIGGGHTS®.
If not, see http://www.gnu.org/licenses . See also top-level README
and LICENSE files.

LIGGGHTS® and CFDEM® are registered trade marks of DCS Computing GmbH,
the producer of the LIGGGHTS® software and the CFDEM®coupling software
See http://www.cfdem.com/terms-trademark-policy for details.

-------------------------------------------------------------------------
Contributing author and copyright for this file:
(if no contributing author is listed, this file has been contributed
by the core developer)

Copyright 2014-     DCS Computing GmbH, Linz
------------------------------------------------------------------------- */

#ifdef COMPUTE_CLASS

ComputeStyle(surface, ComputeSurface)

#else

#ifndef LMP_COMPUTE_SURFACE_H
#define LMP_COMPUTE_SURFACE_H

#include "compute.h"

namespace LAMMPS_NS {

	class ComputeSurface : public Compute {

	public:

		ComputeSurface(class LAMMPS *, int &iarg, int, char **);
		~ComputeSurface();
		void init();
		void init_list(int, class NeighList *);
		double compute_scalar();
		void compute_peratom();
		int pack_reverse_comm(int, int, double *);
		void unpack_reverse_comm(int, int *, double *);
		double memory_usage();

	protected:

		int nmax_;
		class NeighList *list_;

		double *is_on_surface_;

		double point_up_[3];
		double n_vec_up_[3];
		bool use_com_;
		double angle_;
		double cosine_sqr_;
	};

}

#endif
#endif
